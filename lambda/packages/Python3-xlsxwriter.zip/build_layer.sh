#!/bin/bash
export PKG_DIR="python"
rm -rf ${PKG_DIR} && mkdir -p ${PKG_DIR}
#docker run --rm --workdir "/mnt" -v $(pwd):/mnt lambci/lambda:build-python3.7 
pip3 install -r $(pwd)/requirements.txt --no-deps -t ${PKG_DIR}
